const express = require('express'); 
const morgan = require('morgan'); 
const service = require('./src/service');
const { restart } = require('nodemon');

const app = express(); 
const PORT = 8000; 

app.use(morgan('dev')); 
app.use(express.json()); 

app.get("/", (req, res) => {
    res.json({
        message : "Lista de usuarios",
        body : service.getUsers(),
    })
})

app.get('/:id', (req, res) => {
    let { params: { id } } = req; 
    let user = service.getUsers(id); 
    res.json({
        message: `Usuario ${id}`,
        body : user
    })
})

app.post("/", (req,res) =>{
    let { body : newUser} = req
    let user = service.createUser(newUser); 
    res.status(201).json({
        message : "Nuevo usuario creado",
        body : user
    })
})



app.listen(PORT, () => console.log(`Servidor listen in ${PORT} `)); 